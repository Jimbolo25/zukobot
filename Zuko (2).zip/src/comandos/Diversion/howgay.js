const { MessageEmbed } = require('discord.js');

module.exports = {
  name: 'howgay',
  aliases: ['gay'],
  desc: '¡Mide tu porcentaje de homosexualidad!',
  run: async (client, message, args) => {

    let usuario = message.mentions.members.first() || message.guild.members.cache.get(args[0]) || message.member;

    let numero = Math.random() * 100 + 1;
    let coso = Math.floor(numero);

    const embed = new MessageEmbed()
      .setDescription(`¡**${usuario.user.username}** es \`${coso}%\` gay! :rainbow_flag:`)
      .setColor('RANDOM')
    message.reply({embeds: [embed]})
    
  }
}