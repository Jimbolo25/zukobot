module.exports = {
  name: 'say',
  aliases: ['decir'],
  desc: '¡El bot repite lo que digas!',
  run: async (client, message, args, prefix) => {

    let texto = args.join(' ');

    if (!texto) return message.reply('¡Debes escribir lo que quieres que el bot repita! `'+ prefix +'say [Texto]`')

    message.reply({ content: texto, allowedMentions: { parse: [] } });

  }
}