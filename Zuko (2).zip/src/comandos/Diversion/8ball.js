const { MessageEmbed } = require('discord.js');

module.exports = {
  name: '8ball',
  aliases: ['bola8', 'akinator'],
  desc: '¡La bola magica respondera tus dudas!',
  run: async (client, message, args, prefix) => {

    if (!message.channel.permissionsFor(message.guild.me).has("EMBED_LINKS")) return message.reply(`No dispongo del permiso \`Insertar enlaces\`.`);

    let pregunta = args.join(' ');
    var rpts = ["Sí n.n", "No o.o", "Tal vez...", "No lo sé :S", "¡Claro!", "Tenlo por seguro 7w7", "Quizás...", "Imposible...", "Es problable uwu", "Eso es interesante o.o", "¡Por supuesto!", "No digas eso...", "No hay duda acerca de ello..."];

    if (!pregunta) return message.reply('Debes poner una pregunta. `' + prefix + '8ball [Pregunta]`')

    const embed = new MessageEmbed()
      .setTitle('🎱 | Bola 8')
      .addField('**Tu pregunta:**', `${pregunta}`)
      .addField('**Mi respuesta:**', `${rpts[Math.floor(Math.random() * rpts.length)]}`)
      .setFooter({text: `Pregunta hecha por ${message.author.tag}`, iconURL: message.author.avatarURL()})
      .setTimestamp()
      .setColor('RANDOM');
    message.channel.send({ embeds: [embed] });

  }
}