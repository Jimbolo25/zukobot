const figlet = require('figlet');

module.exports = {
  name: 'ascii',
  aliases: [],
  desc: '¡Convierte textos en simbolos!',
  run: async (client, message, args, prefix) => {

    let texto = args.join(' ')
    if(!texto) return message.reply('¡Debes escribir algo! `' + prefix + 'ascii [Texto]`')

    if(texto.length > 14) return message.reply('¡El texto no puede ser mayor a 14 caracteres!')

    figlet(texto, (err, data) => message.reply('```' + data + '```'))

  }
}