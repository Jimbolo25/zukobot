const chistes = require('chistes-aleatorios');

module.exports = {
  name: 'joke',
  aliases: ['chiste', 'chistes'],
  desc: '¡Envia un chiste al azar!',
  run: async (client, message) => {

    const chiste = await chistes.chistes()
    message.reply(chiste)

  }
}