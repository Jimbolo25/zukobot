const { MessageEmbed } = require('discord.js');
const karit = require('ckarit')

module.exports = {
  name: 'meme',
  aliases: ['memes'],
  desc: '¡Envia un meme al azar!',
  run: async (client, message) => {

    if (!message.channel.permissionsFor(message.guild.me).has("EMBED_LINKS")) return message.reply(`No dispongo del permiso \`Insertar enlaces\`.`);


    let meme = await karit.meme()
    const embed = new MessageEmbed()
      .setTitle('Meme Random!')
      .setImage(meme)
      .setColor('RANDOM')
      .setFooter({text: '¡Algunos memes pueden ser ofencivos!'})

    message.reply({embeds: [embed]})

  }
}