const { MessageEmbed } = require('discord.js');
const moment = require("moment");

module.exports = {
  name: 'userinfo',
  aliases: ['uinfo', 'ui'],
  desc: '¡Enseña la informacion de un usuario!',
  run: async (client, message, args) => {

    moment.updateLocale('es');
    moment.locale('es');

    if (!message.channel.permissionsFor(message.guild.me).has("EMBED_LINKS")) return message.reply(`No dispongo del permiso \`Insertar enlaces\`.`);

    let user = message.mentions.members.first() || message.guild.members.cache.get(args[0]) || message.member;

    let creacion = Math.floor(user.user.createdAt / 1000)
    let union = Math.floor(user.joinedAt / 1000)

    let status;
    switch (user.presence ?.status) {
      case 'online':
        status = "🟢 En linea";
        break;
      case 'dnd':
        status = "⛔ No molestar";
        break;
      case 'idle':
        status = "🌙 Ausente";
        break;
      case 'offline':
        status = "⚪ Desconectado";
        break;
    }

    const embed = new MessageEmbed()
      .setTitle('Informacion de ' + user.user.username)
      .setColor('BLUE')
      .setThumbnail(user.user.displayAvatarURL({ dynamic: true }))
      .addField('Cuenta', `• Apodo: **${user.nickname !== null ? `${user.nickname}` : 'No tiene'}**\n• ID: \`${user.user.id}\`\n• Creación: \`${moment(user.user.createdAt, "YYYYMMDD").calendar()}\` (<t:${creacion}:R>)\n• Ingreso al servidor: \`${moment(user.joinedAt, "YYYYMMDD").calendar()}\` (<t:${union}:R>)`)
      .addField('Estado', `${status || '⚪ Desconectado'}`)
      .addField('Lista de roles (Muestra hasta 15)', `${user.roles.cache.map(role => role.toString()).slice(0, 15).join(", ")}`)
    message.reply({ embeds: [embed] })

  }
}