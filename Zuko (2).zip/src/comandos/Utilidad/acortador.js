const YeloApi = require("yeloapi")
const { MessageEmbed } = require('discord.js')

module.exports = {
  name: 'acortador',
  aliases: ['acortar'],
  desc: '¡Convierte un enlace muy grande, en un link pequeño!',
  run: async (client, message, args, prefix) => {

    if (!message.channel.permissionsFor(message.guild.me).has("EMBED_LINKS")) return message.reply(`No dispongo del permiso \`Insertar enlaces\`.`);

    let url = args[0];
    if(!url) return message.reply('¡Debes poner el enlace que quieres acortar! `' + prefix + 'acortador [Enlace]`')

    let urlShorter = await YeloApi.shortURL(url).catch(() => false);
    if (!urlShorter) return message.reply('¡El link que pusiste es invalido!')

    const embed = new MessageEmbed()
      .setTitle('Link acortado!')
      .setDescription(`**Url Acortada:** ${urlShorter.shortenURL}\n**Url Original:** ${urlShorter.originalURL}`)
      .setColor('RANDOM')
    message.reply({embeds: [embed]})

  }
}