const suggestdb = require('../../models/suggest.js');
const { MessageEmbed } = require('discord.js');

module.exports = {
  name: 'suggest',
  aliases: ['sugerencia', 'sugerir'],
  desc: '¡Envia una sugerencia!',
  run: async (client, message, args, prefix) => {

    let datos = await suggestdb.findOne({ guild_id: message.guild.id });
    if (!datos) return message.reply('¡No han seleccionado un canal de sugerencias!')

    let tema = args.join(' ');
    if (!tema) return message.reply('¡Debes escribir una sugerencia! `' + prefix + 'suggest [Sugerencia]`')

    let canal = client.channels.cache.get(datos.channel_id);
    if (!canal) return message.reply('¡No han seleccionado un canal de sugerencias!')

    const embed = new MessageEmbed()
      .setAuthor({ name: `Sugerencia de ${message.author.username} (${message.author.id})`, iconURL: message.author.displayAvatarURL({ dynamic: true }) })
      .setDescription(`${tema}`)
      .setFooter({text: `${message.guild.name}`, iconURL: message.guild.iconURL()})
      .setTimestamp()
      .setColor('BLUE')
    message.reply('¡Sugerencia enviada con exito!')
    canal.send({embeds: [embed]}).then(m => {
      m.react('🔼')
      m.react('🔽')
    })

  }
}