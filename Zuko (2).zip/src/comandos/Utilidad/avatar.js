const { MessageEmbed } = require('discord.js');

module.exports = {
  name: 'avatar',
  aliases: [],
  desc: '¡Muestra el avatar del usuario!',
  run: async (client, message, args) => {

    if (!message.channel.permissionsFor(message.guild.me).has("EMBED_LINKS")) return message.reply(`No dispongo del permiso \`Insertar enlaces\`.`);

    let miembro = message.mentions.users.first() || client.users.cache.get(args[0]) || message.author

    const embed = new MessageEmbed()
      .setTitle(`Avatar de ${miembro.username}`)
      .setURL(`https://cdn.discordapp.com/avatars/${miembro.id}/${miembro.avatar}.png?size=2048`)
      .setColor('RANDOM')
      .setImage(miembro.displayAvatarURL({ size: 4096, dynamic: true }))
    message.reply({embeds: [embed]})

  }
}