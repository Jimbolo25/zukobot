const { MessageEmbed } = require('discord.js');
const traductor = require('@iamtraction/google-translate');

module.exports = {
  name: 'translate',
  aliases: ['traductor', 'traducir'],
  desc: '¡Traduce parrafos cortos de un idioma a otro!',
  run: async (client, message, args, prefix) => {

    if (!message.channel.permissionsFor(message.guild.me).has("EMBED_LINKS")) return message.reply(`No dispongo del permiso \`Insertar enlaces\`.`);

    let idioma = args[0];
    if (!idioma) return message.reply('Debes especificar el idioma! `' + prefix + 'translate [Idioma] [Texto]`')

    let texto = args.slice(1).join(' ')
    if (!texto) return message.reply('Debes poner un texto para traducir! `' + prefix + 'translate [Idioma] [Texto]`')

    traductor(texto, { to: idioma }).then(res => {
      const embed = new MessageEmbed()
        .setTitle('Traductor de Google')
        .setDescription(`Tu texto: **${texto}**\nTraduccion: **${res.text}**`)
        .setColor('RANDOM')
      message.reply({ embeds: [embed] })
    }).catch(err => {
      message.reply('Idioma no disponible!')
    })

  }
}