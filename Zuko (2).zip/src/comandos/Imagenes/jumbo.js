const { MessageAttachment } = require('discord.js');

module.exports = {
  name: 'jumbo',
  aliases: ['emoji'],
  desc: '¡Convierte un emoji en una imagen!',
  run: async (client, message, args) => {

    if(!args[0]) return message.reply('¡Debes poner un emoji!')

    let emoji = message.guild.emojis.cache.find(x => x.name === args[0].split(":")[1])

    if(!emoji) return message.reply('¡Solo se permiten emojis del servidor!')

    const emoji2 = `https://cdn.discordapp.com/emojis/${emoji.id}.${emoji.animated ? 'gif' : 'png'}`

    let attch = new MessageAttachment(emoji2);
    
    message.reply({files: [attch]})

  }
}