const karit = require('ckarit')
const { MessageEmbed } = require('discord.js')

module.exports = {
  name: 'dog',
  aliases: ['perro'],
  desc: '¡Envia una imagen de un perro!',
  run: async (client, message) => {

    if (!message.channel.permissionsFor(message.guild.me).has("EMBED_LINKS")) return message.reply(`No dispongo del permiso \`Insertar enlaces\`.`);

    const perro = await karit.dog()

    const embed = new MessageEmbed()
      .setTitle('Perro!')
      .setImage(perro)
      .setColor('RANDOM')
    message.reply({embeds: [embed]})
  }
}
