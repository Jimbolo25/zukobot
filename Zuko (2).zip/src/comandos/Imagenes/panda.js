const karit = require('ckarit')
const { MessageEmbed } = require('discord.js')

module.exports = {
  name: 'panda',
  aliases: ['oso'],
  desc: '¡Envia una imagen de un panda!',
  run: async (client, message) => {

    if (!message.channel.permissionsFor(message.guild.me).has("EMBED_LINKS")) return message.reply(`No dispongo del permiso \`Insertar enlaces\`.`);

    const perro = await karit.panda()

    const embed = new MessageEmbed()
      .setTitle('Panda!')
      .setColor('RANDOM')
      .setImage(perro)
    message.reply({embeds: [embed]})
  }
}
