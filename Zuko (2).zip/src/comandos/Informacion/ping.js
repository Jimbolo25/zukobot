const { MessageEmbed } = require('discord.js');

module.exports = {
  name: 'ping',
  aliases: [],
  desc: '¡Obten la latencia del bot!',
  run: async (client, message) => {

    if (!message.channel.permissionsFor(message.guild.me).has("EMBED_LINKS")) return message.reply(`No dispongo del permiso \`Insertar enlaces\`.`);

    let ping = Math.floor(message.client.ws.ping);
    let emo = "";
    if (ping > 0 && ping <= 100) {
      emo = '🟢';
    }
    if (ping > 101 && ping <= 300) {
      emo = '🟡'
    }
    if (ping > 301) {
      emo = '🔴'
    }

    const embed = new MessageEmbed()
      .setTitle('Pong!:ping_pong: ')
      .setColor('BLUE')
      .setDescription(` :e_mail: Mensaje: **${Date.now() - message.createdTimestamp}ms** \n${emo} API: **${ping}ms**`)

    message.reply("Cargando...").then(m => {
      setTimeout(() => {
        m.edit({ content: " ", embeds: [embed] })
      }, 2000);
    });

  }
}