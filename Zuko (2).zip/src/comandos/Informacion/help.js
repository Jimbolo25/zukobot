const { MessageEmbed, MessageButton, MessageActionRow } = require('discord.js')
const fs = require('fs');
const path = require('path');

module.exports = {
  name: 'help',
  aliases: ['ayuda'],
  desc: '¡Obten informacion sobre el bot y sus comandos!',
  run: async (client, message, args, prefix) => {

    if (!message.channel.permissionsFor(message.guild.me).has("EMBED_LINKS")) return message.reply(`No dispongo del permiso \`Insertar enlaces\`.`);

    const embed = new MessageEmbed()
      .setTitle('Informacion de Zuko')
      .setDescription('¡Hola! soy **Zuko**, un bot que te ayudara en el día a día de tu servidor.')
      .addField('• Prefix', 'Mi prefijo es `' + prefix + '` y debes usarlo antes de cada uno de mis comandos.')
      .addField('• Comandos', 'Para ver mi lista de comandos usa `'+ prefix +'commands`, para ver informacion sobre ellos usa `' + prefix + 'help (comando)`.')
      .setFooter({ text: 'Fui desarrollado por zJifer#4117, con ayuda de JainaGam3r45#8006 y DaniKiller#9848.', iconURL: message.author.avatarURL() })
      .setColor('RANDOM')

    const boton = new MessageActionRow()
      .addComponents(
        new MessageButton()
          .setURL('https://discord.com/oauth2/authorize?client_id=927362575295991860&permissions=8&scope=bot')
          .setLabel('Invitacion')
          .setStyle('LINK'),
        new MessageButton()
          .setURL('https://discord.gg/xtRkn9QarE')
          .setLabel('Soporte')
          .setStyle('LINK'),
        new MessageButton()
          .setURL('https://zukobot.tk')
          .setLabel('Sitio Web')
          .setStyle('LINK'),
        new MessageButton()
          .setURL('https://paypal.me/jimbolo25')
          .setLabel('Donaciones')
          .setStyle('LINK')     
      )

    if (!args[0]) message.reply({ embeds: [embed], components: [boton] });

    const comando = client.comandos.get(args[0] ?.toLowerCase())

    if (args[0] && !comando) {
      return message.channel.send('No tengo ningun comando llamado `' + args[0] + '` para ver mis comando usa `' + prefix + 'help`.', { allowedMentions: { parse: [] } })
    } else if (comando) {

      const embed1 = new MessageEmbed()
        .setColor('BLUE')
        .addField('Nombre', '```' + comando.name + '```', true)
        .addField('Alias', (comando.aliases ?.length === 0) ? '```' + 'No tiene.' + '```' : `${'```'}${comando.aliases}${'```'}`, true)
        .addField('Descripcion', '```' + comando.desc + '```')
      message.channel.send({ embeds: [embed1] })

    }

  }
}