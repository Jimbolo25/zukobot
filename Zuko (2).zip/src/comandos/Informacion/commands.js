const { MessageEmbed } = require('discord.js')
const fs = require('fs');
const path = require('path');

module.exports = {
  name: 'commands',
  aliases: ['comandos'],
  desc: '¡Muestra los comandos del bot!',
  run: async (client, message, prefix) => {

    if (!message.channel.permissionsFor(message.guild.me).has("EMBED_LINKS")) return message.reply(`No dispongo del permiso \`Insertar enlaces\`.`);

    const embed = new MessageEmbed()
      .setTitle('Comandos disponibles!')
      .addField('• Informacion [4]', fs.readdirSync(path.join(__dirname, '../Informacion')).map(x => "`" + x.slice(0, -3) + "`").join(', '))
      .addField('• Utilidad [5]', fs.readdirSync(path.join(__dirname, '../Utilidad')).map(x => "`" + x.slice(0, -3) + "`").join(', '))
      .addField('• Social [4]', fs.readdirSync(path.join(__dirname, '../Social')).map(x => "`" + x.slice(0, -3) + "`").join(', '))
      .addField('• Diversion [6]', fs.readdirSync(path.join(__dirname, '../Diversion')).map(x => "`" + x.slice(0, -3) + "`").join(', '))
      .addField('• Imagenes [4]', fs.readdirSync(path.join(__dirname, '../Imagenes')).map(x => "`" + x.slice(0, -3) + "`").join(', '))
      .addField('• Reaccion [5]', fs.readdirSync(path.join(__dirname, '../Reaccion')).map(x => "`" + x.slice(0, -3) + "`").join(', '))
      .addField('• Moderacion [3]', fs.readdirSync(path.join(__dirname, '../Moderacion')).map(x => "`" + x.slice(0, -3) + "`").join(', '))
      .addField('• Configuracion [2]', fs.readdirSync(path.join(__dirname, '../Configuracion')).map(x => "`" + x.slice(0, -3) + "`").join(', '))
      .setFooter({ text: 'Para obtener info sobre un comando usa ' + prefix + 'help (comando).', iconURL: message.author.avatarURL() })
      .setColor('BLUE')
    message.reply({ embeds: [embed] });

  }
}