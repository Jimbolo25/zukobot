const progressbar = require('string-progressbar');
const { MessageEmbed } = require('discord.js')

module.exports = {
  name: 'botinfo',
  aliases: ['binfo', 'bi'],
  desc: '¡Muestra la informacion del bot!',
  run: async (client, message) => {

    if (!message.channel.permissionsFor(message.guild.me).has("EMBED_LINKS")) return message.reply(`No dispongo del permiso \`Insertar enlaces\`.`);

    var total = 2048;
    var current = (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)
    var size = 14;
    var slide = "<:lleno:929442492615630958>"
    var line = "<:vacio:929442492846342195>"

    let barra = progressbar.filledBar(total, current, size, line, slide)[0];
    let jj = barra.replace(current, "<:lleno:929442492615630958>").replace(total, "<:vacio:929442492846342195>");

    let a, b;
    a = 2048;
    b = (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2);

    let porcentaje = (b * 100) / a;

    const embed = new MessageEmbed()
      .setColor('BLUE')
      .setTitle('Informacion de Zuko Bot')
      .addField('Creador', '• Nombre: **zJifer#4117**\n• Email: `jifer@zukobot.tk` \n• ID: `424713698108506122`', true)
      .addField('Estadísticas', `• Servidores: \`${client.guilds.cache.size}\`\n• Usuarios: \`${client.users.cache.size}\`\n• Canales: \`${client.channels.cache.size}\``, true)
      .addField('Consumo de RAM:', `${barra} ${Math.round(porcentaje)}%`)
    message.reply({ embeds: [embed] })


  }
}