const { MessageEmbed } = require('discord.js')
const star = require('star-labs')

module.exports = {
  name: 'pat',
  aliases: ['acariciar'],
  desc: '¡Acaricia a un usuario!',
  run: async (client, message, args, prefix) => {

    if (!message.channel.permissionsFor(message.guild.me).has("EMBED_LINKS")) return message.reply(`No dispongo del permiso \`Insertar enlaces\`.`);

    let autor = message.author
    let mencionado = message.mentions.users.first() || client.users.cache.get(args[0])

    if(!mencionado) return message.reply('¡Debes mencionar a un usuario! `' + prefix + 'pat [@Usuario]`')
    if(mencionado.id == autor.id) return message.reply('¡No te puedes acariciar a ti mismo!')

    const embed = new MessageEmbed()
      .setTitle(`${autor.username} acaricio a ${mencionado.username}`)
      .setImage(star.pat())
      .setColor('RANDOM')
    message.reply({embeds: [embed]})

  }
}