const { MessageEmbed } = require('discord.js');

module.exports = {
  name: 'covid',
  aliases: ['hisopado'],
  desc: '¡Crea una prueba de covid falsa!',
  run: async (client, message) => {

    if (!message.channel.permissionsFor(message.guild.me).has("EMBED_LINKS")) return message.reply(`No dispongo del permiso \`Insertar enlaces\`.`);

    let resultados = ['Positivo', 'Negativo']
    let random = resultados[Math.floor(Math.random() * resultados.length)]

    const embed = new MessageEmbed()
      .setTitle('Test de Covid 19')
      .setDescription(`**Usuario:** ${message.author.username}\n**Resultado:** ${random}`)
      .setColor('RANDOM')
    message.reply({ embeds: [embed] })
  }
}