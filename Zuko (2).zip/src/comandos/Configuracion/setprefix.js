const prefixdb = require('../../models/prefix');
const { MessageEmbed } = require('discord.js');

module.exports = {
  name: 'setprefix',
  aliases: ['prefix'],
  desc: '¡Cambia el prefix del bot!',
  run: async (client, message, args, prefix) => {

    if (!message.member.permissions.has("MANAGE_GUILD")) return message.reply('¡No tienes los permisos necesarios!')

    if(!args[0]) return message.reply('¡Debes escribir el nuevo prefix! `' + prefix + 'setprefix [prefix]`')

    if(args[0].length > 3) return message.reply('¡El prefix no puede ser mayor a 3 caracteres!')

    const datos = await prefixdb.findOne({ guild_id: message.guild.id })

    if(datos) {
      await prefixdb.findOneAndUpdate(
        { guild_id: message.guild.id },
        { prefix: args[0] })
    } else {
      let newDatos = new prefixdb({
        guild_id: message.guild.id,
        prefix: args[0]
      })
      await newDatos.save();
    }

    message.reply('¡Mi prefix ahora es `' + args[0] + '`!')

  }
}