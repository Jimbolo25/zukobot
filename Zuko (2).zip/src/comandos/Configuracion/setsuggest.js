const suggestdb = require('../../models/suggest.js')

module.exports = {
  name: 'setsuggest',
  aliases: [],
  desc: '¡Selecciona el canal de sugerencias!',
  run: async (client, message, args, prefix) => {

    if (!message.member.permissions.has("MANAGE_CHANNELS")) return message.reply('¡No tienes los permisos necesarios!')

    let canal = message.mentions.channels.first()
    if(!canal) return message.reply('¡Debes mencionar un canal! `'+ prefix +'setsuggest [#Canal]`')

    if(canal.guild.id !== message.guild.id) return message.reply('¡El canal que mencionaste no pertenece al servidor!')

    if(!canal.permissionsFor(message.guild.me).has('EMBED_LINKS')) return message.reply('¡No puedo enviar mensajes en el canal que mencionaste!');

    const datos = await suggestdb.findOne({ guild_id: message.guild.id })
    if(datos){
      await suggestdb.findOneAndUpdate(
        { guild_id: message.guild.id },
        { channel_id: canal.id})
    } else {
      let newData = new suggestdb({
        guild_id: message.guild.id,
        channel_id: canal.id
      })
      await newData.save();
    }

    message.reply('¡Canal seleccionado con exito!')
    
  }
}