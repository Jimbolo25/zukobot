const economy = require('../../models/economy.js');
const { MessageEmbed } = require('discord.js');

module.exports = {
  name: 'baltop',
  aliases: ['moneytop', 'balancetop', 'top10', 'leaderboard'],
  desc: '¡Observa los 10 usuarios con mas dinero!',
  run: async (client, message) => {

    let data = await economy.find({ server_id: message.guild.id })

    let filterData = data.sort((a, b) => b.money - a.money).slice(0, 10);

    let datos = filterData.map((x, i) => `**${i + 1}.** ${client.users.cache.get(x.user_id)}: $**${x.money}** :dollar:`).join('\n');

    const embed = new MessageEmbed()
      .setTitle(`Top 10 de economia en ${message.guild.name}`)
      .setDescription(datos)
      .setColor('RANDOM')
    message.reply({ embeds: [embed] })

  }
}