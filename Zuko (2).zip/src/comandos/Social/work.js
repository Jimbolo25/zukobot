const economy = require('../../models/economy.js');
const { MessageEmbed } = require('discord.js');

module.exports = {
  name: 'work',
  aliases: ['trabajar'],
  desc: '¡Trabaja y gana dinero!',
  run: async (client, message) => {

    let usuario = message.author.id;
    let server = message.guild.id;

    let trabajos = [
      "Trabajaste de Bombero y te pagaron:",
      "Trabajaste de Policia y te pagaron:",
      "Trabajaste de Guardia y te pagaron:",
      "Trabajaste de Streaper y te pagaron:",
      "Trabajaste de Mesero y te pagaron:",
      "Trabajaste de Cocinero y te pagaron:",
      "Trabajaste de Editor y te pagaron:",
      "Trabajaste de Chofer y te pagaron:",
      "Trabajaste de Modelo y te pagaron:",
      "Trabajaste de DJ y te pagaron:",
      "Trabajaste en YouTube y te pagaron:",
      "Trabajaste en Twitch y te pagaron:",
      "Trabajaste de Mecanico y te pagaron:"
      ]

      let random = trabajos[Math.floor(Math.random() * trabajos.length)];

      const dinero = await economy.findOne({user_id: usuario, server_id: server});

      const cantidad = Math.floor(Math.random() * 200)

      if(dinero) {
        var work = parseInt(dinero.money) + parseInt(cantidad)

        await economy.findOneAndUpdate(
          { user_id: usuario, server_id: server},
          { money: work }
        )
      } else {
        let newCoso = new economy ({
          user_id: usuario,
          server_id: server,
          money: cantidad
        })
        await newCoso.save();
      }
      const embed = new MessageEmbed()
        .setAuthor({name: message.author.tag, iconURL: message.author.avatarURL({ dynamic: true})})
        .setDescription(`${random} **$${cantidad}**`)
        .setColor('GREEN')
      message.reply({embeds: [embed]})

  }
}