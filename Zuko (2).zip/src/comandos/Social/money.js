const economy = require('../../models/economy.js');
const { MessageEmbed } = require('discord.js')

module.exports = {
  name: 'money',
  aliases: ['bal', 'balance', 'dinero'],
  desc: '¡Muestra tu cantidad de dinero!',
  run: async (client, message) => {
    
    let data = await economy.findOne({user_id: message.author.id, server_id: message.guild.id})
    let dinero = ""
    if(data){
      dinero = data.money
    } else {
      dinero = 0
    }

    const embed = new MessageEmbed()
      .setTitle('¡Tu cantidad de dinero!')
      .setDescription(`Hasta el momento tienes **$${dinero}** de dinero.`)
      .setColor('BLUE')
    message.reply({embeds: [embed]})

  }
}