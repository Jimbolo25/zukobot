const cookiedb = require('../../models/cookie.js');
const { MessageEmbed } = require('discord.js')
const cooldown = new Set();

module.exports = {
  name: 'cookie',
  aliases: [],
  cooldown: 43200,
  desc: '¡Envia una galleta de la suerte a un usuario!',
  run: async (client, message, args, prefix) => {

    let usuario = message.mentions.users.first()
    if (!usuario) return message.reply('¡Debes mencionar a un usuario! `' + prefix + 'cookie [@Usuario]`')

    if (cooldown.has(message.author.id)) {
      return message.reply(`¡Solo puedes usar este comando cada **12** horas!`)
    } else {
      cooldown.add(message.author.id);
    }

    let datos1 = await cookiedb.findOne({ user_id: message.author.id });
    let datos2 = await cookiedb.findOne({ user_id: usuario.id });

    if (datos1) {
      datos1.dadas += 1;
      await datos1.save();
    } else {
      let newUser = new cookiedb({
        user_id: message.author.id,
        dadas: 1,
        recividas: 0
      });
      await newUser.save();
    }

    if (datos2) {
      datos2.recividas += 1;
      await datos2.save();
    } else {
      let newUser1 = new cookiedb({
        user_id: usuario.id,
        dadas: 0,
        recividas: 1
      });
      await newUser1.save();
    }

    let coso = await cookiedb.findOne({ user_id: message.author.id });

    const embed = new MessageEmbed()
      .setTitle('Galletas de la suerte')
      .setDescription(`¡Le has dado una galleta a ${usuario.username}!`)
      .setFooter({ text: `📥 ${coso.dadas} | 📤 ${coso.recividas}` })
      .setColor('GREEN')

    message.reply({ embeds: [embed] })

    setTimeout(() => {
      cooldown.delete(message.author.id);
    }, 43200000);

  }
}