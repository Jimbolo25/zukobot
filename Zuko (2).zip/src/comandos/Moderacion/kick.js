module.exports = {
  name: 'kick',
  aliases: [],
  desc: '¡Expulsa a un usuario!',
  run: async (client, message, args, prefix) => {

    if (!message.guild.me.permissions.has("KICK_MEMBERS")) return message.reply(`No dispongo del permiso \`Expulsar usuarios\`.`);

    if (!message.member.permissions.has("KICK_MEMBERS")) return message.reply('¡No tienes los permisos necesarios!')

    let user = message.mentions.members.first() || message.guild.members.cache.get(args[0])

    if (!user) return message.reply('¡Debes mencionar a un usuario! `' + prefix + 'kick [@Usuario] (Motivo)`')
    if (!user.kickable) return message.reply('¡No puedo expulsar a este usuario!')
    if (user.roles.highest.comparePositionTo(message.member.roles.highest) >= 0) return message.reply('¡Este usuario tiene un rol superior o igual al tuyo!')

    let razon = args.slice(1).join(' ');
    if(!razon) razon = '¡No especificada!'

    message.guild.members.kick(user, { reason: razon }).catch((e => {
      message.reply('¡Ocurrio un error!')
    })).then(() => {
      message.reply('¡Usuario expulsado con exito!')
    })

  }
}