module.exports = {
  name: 'slowmode',
  aliases: [],
  desc: '¡Agrega un modo lento a los canales!',
  run: async (client, message, args, prefix) => {

    if (!message.guild.me.permissions.has("MANAGE_GUILD")) return message.reply(`No dispongo del permiso \`Gestionar servidor\`.`);

    if (!message.guild.me.permissionsIn(message.channel).has("EMBED_LINKS")) return message.reply(`No dispongo del permiso \`Gestionar servidor\`.`);

    if (!message.member.permissions.has("MANAGE_GUILD")) return message.reply('¡No tienes los permisos necesarios!')

    let canal = message.channel

    let tiempo = args[0];

    if (tiempo == 'off') {
      canal.setRateLimitPerUser(0)
      return message.reply('¡Modo lento desactivado!')
    }

    if (!tiempo) return message.reply('¡Debes poner el tiempo en segundos! `' + prefix + 'slowmode [Tiempo en segundos]`')

    await canal.setRateLimitPerUser(tiempo).then(() => {

      message.reply('¡El modo lento fue establecido con exito!')

    }).catch(() => {
      message.reply('¡El tiempo introducido no es valido!')
    })


  }
}