module.exports = {
  name: 'ban',
  aliases: [],
  desc: '¡Banea a un usuario!',
  run: async (client, message, args, prefix) => {

    if (!message.guild.me.permissions.has("BAN_MEMBERS")) return message.reply(`No dispongo del permiso \`Banear usuarios\`.`);

    if (!message.member.permissions.has("BAN_MEMBERS")) return message.reply('¡No tienes los permisos necesarios!')

    let user = message.mentions.members.first() || message.guild.members.cache.get(args[0])

    if (!user) return message.reply('¡Debes mencionar a un usuario! `' + prefix + 'ban [@Usuario] (Motivo)`')
    if (!user.bannable) return message.reply('¡No puedo banear a este usuario!')
    if (user.roles.highest.comparePositionTo(message.member.roles.highest) >= 0) return message.reply('¡Este usuario tiene un rol superior o igual al tuyo!')

    let razon = args.slice(1).join(' ');
    if(!razon) razon = '¡No especificada!'

    message.guild.members.ban(user, { reason: razon }).catch((e => {
      message.reply('¡Ocurrio un error!')
    })).then(() => {
      message.reply('¡Usuario baneado con exito!')
    })

  }
}