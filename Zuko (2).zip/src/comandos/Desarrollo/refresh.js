module.exports = {
  name: 'refresh',
  aliases: ['refresh'],
  desc: '¡Refresca un comando!',
  run: async (client, message, args, prefix) => {

    if (!["424713698108506122", "423188993249771521"].includes(message.author.id)) return;

    if (!message.channel.permissionsFor(message.guild.me).has("EMBED_LINKS")) return message.reply(`No dispongo del permiso \`Insertar enlaces\`.`);

    if (!args[0]) return message.reply('¡Debes poner un comando para refrescar! `' + prefix + 'refresh [Comando]`')

    const commandName = args[0]
    const command = message.client.comandos.get(commandName)
      || client.comandos.find(cmd => cmd.aliases && cmd.aliases.includes(commandName));

    if (!command) return message.reply('¡No hay ningun comando con este nombre!');

    delete require.cache[require.resolve(`./${command.name}.js`)];

    try {
      const newCommand = require(`./${command.name}.js`);
      client.commands.set(newCommand.name, newCommand);
      message.reply(`¡El comando \`${command.name}\` fue refrescado!`);
    } catch (error) {
      return message.reply(`¡Ocurrio un error!\n**${error.name}:** ${error.message}`)
    }

  }
}