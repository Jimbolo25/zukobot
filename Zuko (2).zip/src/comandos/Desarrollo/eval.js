const { MessageEmbed } = require('discord.js')

module.exports = {
  name: 'eval',
  aliases: ['e'],
  desc: '¡Ejecuta una linea de codigo rapidamente!',
  run: async (client, message, args, prefix) => {

    if (!["424713698108506122", "423188993249771521"].includes(message.author.id)) return;

    if (!message.channel.permissionsFor(message.guild.me).has("EMBED_LINKS")) return message.reply(`No dispongo del permiso \`Insertar enlaces\`.`);

    function mayuscula(string) {
      string = string.replace(/[^a-z]/gi, '')
      return string[0].toUpperCase() + string.slice(1)
    }

    let outpout = args[0]
    if (!outpout) return message.reply('¡Debes poner algo para evaluar! `' + prefix + 'eval [Codigo]`')

    let tiempo = Date.now()

    let words = ["client.token"]
    if (words.some(word =>
      message.content.toLowerCase().includes(word))) {
      return message.reply('¡Estas intentando evaluar algo peligroso!')
    }

    try {

      let salida = eval(args.join(' '))
      let tipo = typeof salida || 'Desconocido'
      if (typeof salida !== "string") salida = require("util").inspect(salida);
      const embed = new MessageEmbed()
        .setTitle('Evaluacion hecha!')
        .addField('Tipo:', `\`\`\`js\n${mayuscula(tipo)}\n\`\`\``, true)
        .addField('Tiempo:', `\`\`\`fix\n${Date.now() - tiempo}ms\n\`\`\``, true)
        .addField('Entrada:', `\`\`\`js\n${args.join(' ')}\n\`\`\``)
        .addField('Salida:', `\`\`\`js\n${salida.slice(0, 990)}\n\`\`\``)
        .setColor('RANDOM')
      message.reply({ embeds: [embed] })

    } catch (error) {
      return message.reply(`¡Ocurrio un error!\n**${error.name}:** ${error.message}`)
    }

  }
}