const { MessageEmbed } = require('discord.js');
const h = require('humanize-duration');

module.exports = async (client, guild) => {

  let canal = client.channels.resolve('928771258223562883')
  let humanos = guild.members.cache.filter(x => !x.user.bot).size
  let bots = guild.members.cache.filter(o => o.user.bot).size
  let servidores = client.guilds.cache.size
  let owner = await guild.fetchOwner()

  const embed = new MessageEmbed()
    .setAuthor({name: guild.name + ' (' + guild.id + ')', iconURL: guild.iconURL({ dynamic: true })})
    .addField('Creador:', '```' + owner.user.tag + ' (' + guild.ownerId + ')```')
    .addField('Miembros:', '```' + `${humanos} Usuarios | ${bots} Bots` + '```', true)
    .addField('Contador:', '```' + `${servidores} Servidores` + '```', true)
    .addField('Fecha de creacion:', '```' + `${guild.createdAt.toLocaleDateString()}, a las ${guild.createdAt.getHours()}:${guild.createdAt.getMinutes() < 10 ? "0"+guild.createdAt.getMinutes() : guild.createdAt.getMinutes()} ${guild.createdAt.getHours() >= 12 ? 'PM' : 'AM'} (Hace ${h(guild.createdAt - Date.now(), { round: true, language: "es", largest: 2 })})` + '```')
    .setColor("GREEN")
  canal.send({embeds: [embed]}).catch({})

}