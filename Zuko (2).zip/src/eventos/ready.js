const { ActivitiesOptions } = require('discord.js');
const DBL = require('dblapi.js');
const votekey = process.env.VOTEKEY;
const dbl = new DBL(votekey);

module.exports = async (client) => {

  console.log('Encendido con exito!')

  const coso = [
    { name: 'zukobot.tk', type: 'WATCHING' },
    { name: 'ser el mejor!', type: 'COMPETING' },
    { name: `${client.guilds.cache.size} servidores!`, type: 'WATCHING' },
    { name: 'mc.jifercraft.ml', type: 'PLAYING' },
    { name: `${client.users.cache.size} usuarios!`, type: 'WATCHING' },
    { name: `${client.comandos.size} comandos!`, type: 'WATCHING' }
  ]

  setInterval(() => {
    const coso2 = coso[Math.floor(Math.random() * coso.length)]

    client.user.setPresence({
      activities: [coso2],
      status: 'online'
    })


  }, 60000)

  setInterval(() => {
    dbl.postStats(client.guilds.cache.size);
  }, 1800000);
}