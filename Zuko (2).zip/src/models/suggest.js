const mongoose = require('mongoose')

const suggestdb = new mongoose.Schema({
  guild_id: { type: String },
  channel_id: { type: String }
})

module.exports = mongoose.model('suggestdb', suggestdb);