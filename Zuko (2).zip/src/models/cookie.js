const mongoose = require('mongoose');

const cookiedb = new mongoose.Schema({
  user_id: { type: String },
  dadas: { type: Number },
  recividas: { type: Number }
});

module.exports = mongoose.model('cookie', cookiedb);