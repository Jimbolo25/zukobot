const mongoose = require('mongoose')

const prefixdb = new mongoose.Schema({
  prefix: { type: String },
  guild_id: { type: String }
});

module.exports = mongoose.model('prefixdb', prefixdb);