const mongoose = require('mongoose');

const economy = new mongoose.Schema({
  user_id: { type: String },
  server_id: { type: String },
  money: { type: Number }
});

module.exports = mongoose.model('economy', economy)