const mongoose = require('mongoose');
const zukodb = process.env.DB;

module.exports = mongoose.connect(zukodb, {
  useNewUrlParser: true
})