require('dotenv').config();
const { Client, Intents, Collection } = require('discord.js');
const mongoose = require('mongoose');
const token = process.env.TOKEN;
const fs = require("fs");

const client = new Client({ intents: [Intents.FLAGS.GUILDS, Intents.FLAGS.GUILD_MESSAGES, Intents.FLAGS.GUILD_PRESENCES], ws: { properties: { $browser: "Discord iOS" } } });

const db = require('./config/db');

db.then(() => {
  console.log("Conectado a la base de datos con exito!")
});

fs.readdir("./src/eventos/", (err, files) => {
  if (err) return console.error(err);
  files.forEach(file => {
    const evento = require(`./src/eventos/${file}`);
    let eventoName = file.split(".")[0];
    try {
      client.on(eventoName, evento.bind(null, client));
      console.log(`[Evento] ¡${eventoName} ha sido cargado con éxito!`)
    } catch (e) {
      console.log(`[Evento] ¡${eventoName} no se ha podido cargar! Detalles del error: ${e}`);
    }
  });
});

let loadCommands = function(client) {
  const { promisify } = require("util");
  const readdir = promisify(require("fs").readdir);
  try {
    let carpetas = ["Informacion", "Utilidad", "Social", "Diversion", "Imagenes", "Reaccion", "Moderacion", "Configuracion", "Desarrollo"];
    carpetas.forEach(c => {
      let dir = `./src/comandos/${c}/`;
      readdir(dir, (err, files) => {
        if (err) throw err;
        console.log(`[COMANDOS] ¡Se cargaron ${files.length} comandos! (en la categoría ${c})`);
        files.forEach(f => {
          files.forEach(file => {
            if (fs.lstatSync(dir + f).isDirectory()) {
              loadCommands(dir + f);
              return;
            }

            let props = require(`${dir}${f}`);
            client.comandos.set(props.name, props);

          });
        });
      });
    });
  } catch (e) { };
};
loadCommands(client);
client.comandos = new Collection();

client.login(token).then(() => console.info("[TOKEN] ¡" + client.user.tag + " ha iniciado sesión con éxito!")).catch((e) => console.error(e));